﻿using System.Web;

namespace StupidBDWebApp
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
