﻿using System;
using System.Web;
using System.Web.UI;
namespace StupidBDWebApp
{
    public partial class master : System.Web.UI.MasterPage
    {
    }
}
